package LibreriaWeb.DonPepe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonPepeApplicationTests {

	@Test
	void contextLoads() {
	}

}
